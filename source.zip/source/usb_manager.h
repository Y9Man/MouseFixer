#pragma once
#include <windows.h>
#include <setupapi.h>
#include <devguid.h>
#include <string>
#include <vector>

#pragma comment(lib, "setupapi.lib")

class USBManager {
public:
    static bool restartUSBDevice(const std::string& deviceName);
    static std::vector<std::string> findMiceDevices();

private:
    static bool disableUSBDevice(const std::string& deviceId);
    static bool enableUSBDevice(const std::string& deviceId);
    static std::string getDeviceInstanceId(const std::string& deviceName);
};