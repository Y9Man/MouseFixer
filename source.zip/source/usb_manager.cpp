#include "usb_manager.h"
#include <iostream>
#include <cfgmgr32.h>

std::vector<std::string> USBManager::findMiceDevices() {
    std::vector<std::string> mice;
    HDEVINFO deviceInfoSet = SetupDiGetClassDevs(&GUID_DEVCLASS_MOUSE, NULL, NULL, DIGCF_PRESENT);

    if (deviceInfoSet == INVALID_HANDLE_VALUE) return mice;

    SP_DEVINFO_DATA deviceInfoData;
    deviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    for (DWORD i = 0; SetupDiEnumDeviceInfo(deviceInfoSet, i, &deviceInfoData); i++) {
        CHAR deviceName[256];
        DWORD size = sizeof(deviceName);

        if (SetupDiGetDeviceRegistryPropertyA(deviceInfoSet, &deviceInfoData, SPDRP_DEVICEDESC,
            NULL, (PBYTE)deviceName, size, &size)) {
            mice.push_back(deviceName);
        }
    }

    SetupDiDestroyDeviceInfoList(deviceInfoSet);
    return mice;
}

std::string USBManager::getDeviceInstanceId(const std::string& deviceName) {
    HDEVINFO deviceInfoSet = SetupDiGetClassDevs(&GUID_DEVCLASS_MOUSE, NULL, NULL, DIGCF_PRESENT);
    if (deviceInfoSet == INVALID_HANDLE_VALUE) return "";

    SP_DEVINFO_DATA deviceInfoData;
    deviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    for (DWORD i = 0; SetupDiEnumDeviceInfo(deviceInfoSet, i, &deviceInfoData); i++) {
        CHAR name[256];
        DWORD size = sizeof(name);

        if (SetupDiGetDeviceRegistryPropertyA(deviceInfoSet, &deviceInfoData, SPDRP_DEVICEDESC,
            NULL, (PBYTE)name, size, &size)) {
            if (deviceName == name) {
                CHAR instanceId[256];
                size = sizeof(instanceId);
                if (SetupDiGetDeviceInstanceIdA(deviceInfoSet, &deviceInfoData, instanceId, size, &size)) {
                    SetupDiDestroyDeviceInfoList(deviceInfoSet);
                    return instanceId;
                }
            }
        }
    }

    SetupDiDestroyDeviceInfoList(deviceInfoSet);
    return "";
}

bool USBManager::disableUSBDevice(const std::string& deviceId) {
    DEVINST devInst;
    if (CM_Locate_DevNodeA(&devInst, (DEVINSTID_A)deviceId.c_str(), CM_LOCATE_DEVNODE_NORMAL) != CR_SUCCESS) {
        return false;
    }

    return CM_Disable_DevNode(devInst, 0) == CR_SUCCESS;
}

bool USBManager::enableUSBDevice(const std::string& deviceId) {
    DEVINST devInst;
    if (CM_Locate_DevNodeA(&devInst, (DEVINSTID_A)deviceId.c_str(), CM_LOCATE_DEVNODE_NORMAL) != CR_SUCCESS) {
        return false;
    }

    return CM_Enable_DevNode(devInst, 0) == CR_SUCCESS;
}

bool USBManager::restartUSBDevice(const std::string& deviceName) {
    std::string instanceId = getDeviceInstanceId(deviceName);
    if (instanceId.empty()) {
        std::cout << "���������� �� �������: " << deviceName << std::endl;
        return false;
    }

    std::cout << "������������ USB ����������: " << deviceName << std::endl;

    if (!disableUSBDevice(instanceId)) {
        std::cout << "������ ���������� ����������" << std::endl;
        return false;
    }

    Sleep(2000);

    if (!enableUSBDevice(instanceId)) {
        std::cout << "������ ��������� ����������" << std::endl;
        return false;
    }

    Sleep(3000);
    std::cout << "USB ���������� ������������� �������!" << std::endl;
    return true;
}