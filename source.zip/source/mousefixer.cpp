﻿#include <Windows.h>
#include <iostream>
#include <thread>
#include <atomic>
#include <chrono>
#include <string>
#include <locale>
#include <codecvt>
#include "config.h"
#include "usb_manager.h"


void setRussianLocale() {
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    setlocale(LC_ALL, "Russian");
}

class MouseMonitor {
private:
    std::atomic<bool> running;
    int checkIntervalMs;
    int stuckThreshold;

public:
    MouseMonitor() : running(true) {
        checkIntervalMs = Config::CHECK_INTERVAL_MS;
        stuckThreshold = Config::STUCK_THRESHOLD;
    }

    void monitorMouse() {
        POINT lastPos;
        GetCursorPos(&lastPos);
        int stuckCount = 0;
        int recoveryAttempts = 0;

        std::cout << "=== Mouse Monitor ===" << std::endl;
        std::cout << "Searching for USB mice..." << std::endl;

        
        auto mice = USBManager::findMiceDevices();
        for (const auto& mouse : mice) {
            std::cout << "Found mouse: " << mouse << std::endl;
        }

        if (mice.empty()) {
            std::cout << "No mice found! Check connection." << std::endl;
            return;
        }

        std::string targetMouse = mice[0];

        std::cout << "Monitoring started. Interval: " << checkIntervalMs << "ms" << std::endl;
        std::cout << "Press Ctrl+C to exit" << std::endl;

        while (running) {
            POINT currentPos;
            GetCursorPos(&currentPos);

            if (currentPos.x == lastPos.x && currentPos.y == lastPos.y) {
                stuckCount++;

                if (stuckCount > stuckThreshold) {
                    recoveryAttempts++;
                    std::cout << "\n[" << getCurrentTime() << "] Problem detected! "
                        << "Recovery attempt #" << recoveryAttempts << std::endl;

                    
                    if (Config::USE_CURSOR_MOVE_METHOD) {
                        tryCursorMoveMethod();
                    }

                    if (Config::USE_INPUT_SIMULATION_METHOD) {
                        tryInputSimulationMethod();
                    }

                    
                    if (stuckCount > stuckThreshold * 2 && Config::ENABLE_USB_RESTART) {
                        std::cout << "Attempting USB restart..." << std::endl;
                        if (USBManager::restartUSBDevice(targetMouse)) {
                            std::cout << "USB restarted successfully!" << std::endl;
                            stuckCount = 0;
                            recoveryAttempts = 0;
                        }
                    }
                }
            }
            else {
                if (stuckCount > 0) {
                    std::cout << "Cursor movement restored" << std::endl;
                    stuckCount = 0;
                    recoveryAttempts = 0;
                }
            }

            lastPos = currentPos;
            std::this_thread::sleep_for(std::chrono::milliseconds(checkIntervalMs));
        }
    }

    bool tryCursorMoveMethod() {
        POINT pos;
        GetCursorPos(&pos);

        bool success1 = SetCursorPos(pos.x + 1, pos.y);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        bool success2 = SetCursorPos(pos.x, pos.y);

        std::cout << "Cursor move method: " << (success1 && success2 ? "Success" : "Failed") << std::endl;
        return success1 && success2;
    }

    bool tryInputSimulationMethod() {
        INPUT input = { 0 };
        input.type = INPUT_MOUSE;
        input.mi.dwFlags = MOUSEEVENTF_MOVE;
        bool success = SendInput(1, &input, sizeof(INPUT)) == 1;

        std::cout << "Input simulation method: " << (success ? "Success" : "Failed") << std::endl;
        return success;
    }

    std::string getCurrentTime() {
        auto now = std::chrono::system_clock::now();
        auto in_time_t = std::chrono::system_clock::to_time_t(now);

        char buffer[80];
        ctime_s(buffer, sizeof(buffer), &in_time_t);
        buffer[strlen(buffer) - 1] = '\0';

        return std::string(buffer);
    }

    void stop() {
        running = false;
    }
};


BOOL WINAPI ConsoleHandler(DWORD signal) {
    if (signal == CTRL_C_EVENT) {
        std::cout << "\nShutting down..." << std::endl;
        exit(0);
    }
    return FALSE;
}

void showHelp() {
    std::cout << "========================================" << std::endl;
    std::cout << "MouseFixer - Mouse Monitoring and Recovery" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "Edit config.cpp to change settings" << std::endl;
    std::cout << "запусти от имени администратора, чтобы работать с USB!" << std::endl;
    std::cout << "Press Ctrl+C to exit" << std::endl;
    std::cout << "========================================" << std::endl;
}

int main() {
    setRussianLocale();
    SetConsoleCtrlHandler(ConsoleHandler, TRUE);


    Config::CHECK_INTERVAL_MS = 100;
    Config::STUCK_THRESHOLD = 30;
    Config::ENABLE_USB_RESTART = true;

    showHelp();

    MouseMonitor monitor;
    std::thread monitorThread(&MouseMonitor::monitorMouse, &monitor);


    monitorThread.join();

    return 0;
}