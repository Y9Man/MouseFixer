MouseFixer


Problem
Mouse cursor freezes but mouse continues sending signals

Solution
Background application that automatically detects and recovers mouse functionality

Features
- Mouse movement monitoring
- Automatic recovery attempts  
- USB device restart (admin required)
- Configurable settings

Download
[Latest Release](./release/mousefixer_v1.0.zip)

Build from Source
Requires Visual Studio 2022